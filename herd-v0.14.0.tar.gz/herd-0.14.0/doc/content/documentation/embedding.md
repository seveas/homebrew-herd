---
Title: Using herd as a library
Weight: 7
---

The Herd API has only recently become stable enough to consider using it as a library. Both the API
documentation and the high level documentation still need to be written though. Stay tuned!

# Library versus CLI tool
# Basic building blocks
# Using the scripting engine
# Selecting providers
# Custom UI
