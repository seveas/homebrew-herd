Herd documentation
==================
This is the website and documentation for herd. It's built with hugo and primer, hence all the extra
files in here. The source for the documentation lives in content/documentation/

Building the docs
=================
You will need go, hugo, dart-sass and npm. All can be installed with homebrew: `brew install go hugo sass/sass/sass`
