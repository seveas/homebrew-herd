package herd

import (
	"fmt"
	"strings"
)

type MultiError struct {
	Subject  string
	messages []string
}

func (m *MultiError) Error() string {
	if m.Subject != "" && len(m.messages) != 0 {
		return fmt.Sprintf("%s:\n%s", m.Subject, strings.Join(m.messages, "\n"))
	}
	return strings.Join(m.messages, "\n")
}

func (m *MultiError) Add(e error) {
	m.messages = append(m.messages, e.Error())
}

func (m *MultiError) HasErrors() bool {
	return len(m.messages) > 0
}
