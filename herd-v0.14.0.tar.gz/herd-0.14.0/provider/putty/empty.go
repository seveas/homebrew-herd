package putty

// Intentinally empty so we have something to compile on non-windows OS'es
