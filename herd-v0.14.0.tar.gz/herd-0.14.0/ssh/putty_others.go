//go:build !windows
// +build !windows

package ssh

func readPuttyConfig(c *config, name string) {
}
